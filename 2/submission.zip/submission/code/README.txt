Run main.py for most of the filters
align_image was used for some image alignment
custom_mask was used to create the mask for the 3rd hybrid image
oraple.py was used for all image morphing
display_frequencies was used to display the Fourier transforms